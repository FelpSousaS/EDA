//Nome: Felipe de Sousa Santos - Matricula: 414235

#include <iostream>
#include <string>
#include <stdlib.h>
#include "item.h"
#include "avl.h"
#include "avl.cpp"
using namespace std;
using std::cout;
using std::endl;

int main(int argc, char** argv){
    Node *aux1 = NULL;
    Node *aux2 = NULL;
    string chave, valor, busca;
    int op = 0, alt = 0;
    
    while(op != 8){
        cout<< "------------Menu AVL------------" << endl;
        cout<< "1. Inserir Elemento"<< endl;
        cout<< "2. Apagar todos os nos da arvore"<< endl;
        cout<< "3. Percorrer em pre-ordem"<< endl;
        cout<< "4. Percorrer em ordem"<< endl;
        cout<< "5. Percorrer em pos-ordem"<< endl;
        cout<< "6. Pesquisar elemento"<< endl;
        cout<< "7. Calcular altura da arvore"<< endl;
        cout<< "8. Fechar"<< endl;
        cout<< endl;
    
    
        cout<< "Informe a operacao que deseja realizar: " << endl;
        cin>> op;
        cout<< endl;

        switch(op){
                case 1: cout << "Insira o valor da chave: "<< endl;
                        cin>>chave;
                        cout<< endl;
                        cout<< "Digite o valor a ser inserido: "<< endl;
                        cin>>valor;
                        cout<< endl;
                        aux1 = inserir(aux1, chave, valor);
                        cout<<"Node inserido com sucesso!"<< endl;
						cout<< endl;
                break;

                case 2: aux1 = delete_avl(aux1);
                        cout<<"arvore deletada!";
						cout<< endl;
                break;

                case 3: cout<<"Percurso em pre-ordem: "<<endl;
                        preordem(aux1);
                break;        

                case 4: cout << "Percurso em ordem: "<< endl;
                        emordem(aux1);
                break;

                case 5: cout << "Percurso em pos-ordem: "<< endl;
                        posordem(aux1);        
                break;

                case 6: cout<< "Informe o valor que deseja buscar: "<< endl;
                        cin>> busca;
                        aux2 = buscar(aux1, busca);
                        if(aux2 == NULL) {
						   	cout<< "Nao encontrado!"<< endl;
                        	cout<< endl;
					 	}	
                        else cout<< "O valor " + aux2->valor + " foi encontrado com sucesso!"<< endl;
                break;

                case 7: alt = altura(aux1);
                        cout<< "A altura da arvore e: " + alt<< endl;
                        cout<< endl;
                break;

                case 8: exit(0); 

                default: cout<<"Operacao invalida!"<< endl;  
        }         
    }
    return 0;	
}

