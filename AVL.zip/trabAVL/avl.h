#ifndef AVL_H
#define AVL_H
#include <iostream> 
#include "item.h"

struct Node;

Key getKey(Node *node);
Value getValue(Node *node);
Node *buscar(Node *node, Key chave);
void preordem(Node *node);
void emordem(Node *node);
void posordem(Node *node);
int altura(Node *node);
int tamanho_avl(Node *node);
int balanco(Node *node);
bool avl_vazia(Node *node);
Node *rotacao_dir(Node *node);
Node *rotacao_esq(Node *node);
Node* alocar_node(Key chave, Value valor);
Node *fixup_node(Node *n, Key chave);
Node *inserir(Node *n, Key chave, Value valor);
Node *delete_avl(Node *node);

#endif 
