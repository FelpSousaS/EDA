#ifndef ITEM_H
#define ITEM_H
#include <string>

typedef std::string Key;
typedef std::string Value;

#endif