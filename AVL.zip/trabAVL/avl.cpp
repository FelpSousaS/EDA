#include <iostream>
#include <queue>
#include <cstddef>
#include "avl.h"
#include "item.h"
using std::cout;
using std::endl;


struct Node{
	Key chave;
	Value valor;
	int height;
	Node *left;
	Node *right;
};

Key getKey(Node *node){
	return node->chave;
}

Value getValue(Node *node){
	return node->valor;
}

Node *buscar(Node *node, Key chave){
	if(node == NULL) return NULL;
	if(chave < node->chave) return buscar(node->left,chave);
	else if(chave > node->chave) return buscar(node->right,chave);
	else return node; 
}

void preordem(Node *node){
	if(node != NULL){
		cout<< "(" << node->chave << "," << node->valor << ")" << endl;
		preordem(node->left);
		preordem(node->right);
	}
}

void emordem(Node *node){
	if(node != NULL){
		emordem(node->left);
		cout<< "(" << node->chave << "," << node->valor << ")" << endl;
		emordem(node->right);
	}
}

void posordem(Node *node){
	if(node != NULL){
		posordem(node->left);
		posordem(node->right);
		cout<< "(" << node->chave << "," << node->valor << ")" << endl;
	}
}

int altura(Node *node){ // calcula a altura da arvore
	if(node == NULL) return 0;
	else return node->height;
}

int tamanho_avl(Node *node){ // retorna o tamanho da arvore
	if(node == NULL) return 0;
	else return 1 + tamanho_avl(node->left) + tamanho_avl(node->right);
}

int balanco(Node *node){ // calcula o balanceamento do node
	if(node == NULL) return 0;
	return altura(node->right) - altura(node->left);
}

bool avl_vazia(Node *node){ //verifica se a arvore eh vazia
	return (node == NULL);
}

Node *rotacao_dir(Node *node){ 
	Node *aux = node->left;
	node->left = aux->right;
	aux->right = node;

	node->height = 1 + std:: max(altura(node->left), altura(node->right));
	aux->height = 1 + std:: max(altura(aux->left), altura(aux->right));

	return aux;
}

Node *rotacao_esq(Node *node){
	Node *aux = node->right;
	node->right = aux->left;
	aux->left = node;

	node->height = 1 + std:: max(altura(node->left), altura(node->right));
	aux->height = 1 + std:: max(altura(aux->left), altura(aux->right));

	return aux;
}

Node* alocar_node(Key chave, Value valor){ //alocar nodes
	Node *node = new Node;
	node->chave = chave;
	node->valor = valor;
	node->left = NULL;
	node->right = NULL;
	node->height = 1;
	return node;
}

Node *fixup_node(Node *n, Key chave){
	int fb = balanco(n); // obter balanco do node.
	
	if(fb < -1 && chave < n->left->chave) return rotacao_dir(n);
	else if(fb < -1 && chave > n->left->chave){
		n->left = rotacao_esq(n->left);
		return rotacao_dir(n);
	}
	else if(fb > 1 && chave > n->right->chave) return rotacao_dir(n);
	else if(fb > 1 && chave < n->right->chave){
		n->right = rotacao_dir(n->right);
		return rotacao_esq(n);
	}
	return n;
}

Node *inserir(Node *n, Key chave, Value valor){// inserir nodes
	if(n == NULL) return alocar_node(chave, valor);
	
	if(chave < n->chave) n->left = inserir(n->left, chave, valor);
	else if(chave > n->chave) n->right = inserir(n->right, chave, valor);
	else return n;

	n->height = 1 + std:: max(altura(n->left), altura(n->right));
	n = fixup_node(n, chave); //regula node.
	return n;
} 

Node *delete_avl(Node *node){ //deleta a arvore inteira
	if(node == NULL) return NULL;
	if(node->left == NULL && node->right == NULL){
		delete node;
		return NULL;
	}
	delete_avl(node->left);
	delete_avl(node->right);
	delete node;
	return NULL;
}