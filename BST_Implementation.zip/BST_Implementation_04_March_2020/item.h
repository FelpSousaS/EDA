/**
 * -- item.h --------------------------------
 * Header file with definition of 'new' types
 */
#ifndef ITEM_H
#define ITEM_H

typedef int Tkey; 
typedef float Tvalue; 

#endif 