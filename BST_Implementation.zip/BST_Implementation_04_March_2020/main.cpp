#include <iostream>
#include <cstdlib>
#include "item.h"
#include "bst.h"
using namespace std;

/**
 * Esta funcao recebe um ponteiro para um no da arvore e
 * imprime na tela os valores do par (chave,valor) multiplicados por 2 */
void dobraPar(Node *node) {
    Tkey k = 2 * bst_getKey(node);
    Tvalue v = 2 * bst_getValue(node);
    cout << "(" << k << ", " << v << ")" << endl;
}

/**
 * Entrada: Esta funcao recebe um vetor A de inteiros ORDENADOS, 
 * o indice l do primeiro elemento, o indice r do ultimo
 * elemento, e o endereco da raiz da arvore.
 * ----------
 * Saida: o ponteiro root, ao final da funcao, apontara para 
 * a raiz de uma arvore completa (com altura lg(n+1)) 
 * */
void create_balancedTree(int A[], int l, int r, Node **root) {
	if(l <= r) {
		int m = (l + r)/2;
		*root = bst_insert(*root, A[m], (double) (rand() % 100) / 101);
		create_balancedTree(A, l, m-1, root);
		create_balancedTree(A, m+1, r, root);
	}
}

int main() {
    Node *root = nullptr; // cria arvore vazia

    const int MAX = 30;
    int vec[MAX];

    // cria vetor de inteiros ordenados
    for(int i = 0; i < MAX; i++)
        vec[i] = i;

    // cria arvore completa ( ou seja, com altura lg(n+1) )
    create_balancedTree(vec, 0, MAX-1, &root);

    // percorre arvore em preordem
    cout << "Pares (chave, valor) armazenados na arvore:\n";
    bst_preorder(root);

    // percorre arvore em preordem executando funcao especifica durante a visita do no
    cout << "\nPares (chave, valor) com valores multiplicados por 2:\n";
    bst_preorder(root, dobraPar);

    // libera todos os nos alocados dinamicamente, deixando a arvore vazia
    cout << "\nDestruindo a arvore...\n";
    root = bst_clear(root);

    return 0;
}
