#include <iostream>
#include "item.h"
#include "bst.h"
using std::cout;
using std::endl;

struct Node {
    Tkey key;
    Tvalue value;
    Node *left;
    Node *right;
};

Tkey bst_getKey(Node *node) {
    return node->key;
}

Tvalue bst_getValue(Node *node) {
    return node->value;
}

Node *bst_search(Node *node, Tkey mykey) {
    if(node == nullptr)
        return nullptr;
    if(node->key == mykey)
        return node;
    if(mykey < node->key)
        return bst_search(node->left, mykey);
    else 
        return bst_search(node->right, mykey);
}

Node *bst_insert(Node *node, Tkey mykey, Tvalue value) {
    if(node == nullptr) {
        node = new Node;
        node->key = mykey;
        node->value = value;
        node->left = node->right = nullptr;
    }
    else if(mykey < node->key) 
        node->left = bst_insert(node->left, mykey, value);
    else if(mykey > node->key)
        node->right = bst_insert(node->right, mykey, value);
    
    return node;
}

void bst_preorder(Node *node) {
    if(node != nullptr) {
        cout << "(" <<node->key << ", " << node->value << ")" << endl;
        bst_preorder(node->left);
        bst_preorder(node->right);
    }
}

void bst_preorder(Node *node, void f(Node*)) {
    if(node != nullptr) {
        f(node);
        bst_preorder(node->left, f);
        bst_preorder(node->right, f);
    }
}

Node *bst_clear(Node *node) {
    if(node != nullptr) {
        node->left = bst_clear(node->left);
        node->right = bst_clear(node->right);
        cout << "Liberando o nó " << node->key << endl;
        delete node;
    }
    return nullptr;
}